import tkinter as tk
from tkinter import scrolledtext
import socket
import threading
import json
from openai import OpenAI
import time
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.widgets.scrolled import ScrolledText

HOST = "127.0.0.1"
PORT = 8765
MODEL = "gpt-4o-mini"

client = OpenAI(
    api_key="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"
)

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connected = False

while not connected:
    try:
        sock.connect((HOST, PORT))
        connected = True
        print("Connected to Webots Supervisor!")
    except:
        print("Waiting for Webots to open port...")
        time.sleep(1)


def ask_chatgpt(user_text, recent_status):
    import time
    t_start = time.time()
    system_prompt = """
    You are the AI supervisor of a multi-robot masonry system.

Your task is to perform deep natural-language understanding (NLU) on user commands 
and infer the *final actionable intent* for the robot system.

⚠ INTERNAL REASONING RULES (DO NOT OUTPUT THE REASONING)
1. You must internally analyse:
   - multi-stage instructions
   - uncertainty or hesitation
   - conflicting statements
   - corrections ("change to…", "actually…")
   - implied requests ("about chest-height", "taller than before")
   - metaphor, vague language, non-numerical descriptions
   - noise, slang, emojis, mixed languages

2. You must infer the user's *final desired number of layers* even when:
   - the user gives multiple intermediate steps
   - the user expresses doubt ("maybe", "around")
   - the user mentions tasks that are irrelevant (spraying, polishing, decoration)

3. If the user expresses preferences, intentions, goals, or high-level conditions,
   convert them into the most reasonable final layer count.

4. Always isolate the FINAL intention, not intermediate or historical instructions.

⚠ OUTPUT RULES (VERY IMPORTANT)
1. You MUST output ONLY JSON in ASCII:
      {"action": "build_wall", "layers": N}

2. No comments, no extra text, no Chinese characters, no unicode.

3. If the user does not imply any number, default N = 3.

4. If the user's request is ambiguous but suggests a range:
      "a small wall", "chest height", "just a bit taller"
   infer the closest reasonable number:
      small = 2-3, medium = 3-4, tall = 5-6

5. NEVER return intermediate numbers. Only the final inferred N.


    """

    completion = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Recent status:\n{recent_status}"},
            {"role": "user", "content": user_text},
        ],
        response_format={"type": "json_object"}
    )

    t_end = time.time()
    resp_time = t_end - t_start

    gui_log(f"[METRIC] GPT Response Time = {resp_time:.3f} s")

    return completion.choices[0].message.content


def send_to_webots(json_msg):
    try:
        sock.sendall((json_msg + "\n").encode("utf-8"))
    except:
        gui_log("ERROR: Failed to send message to Webots")


robot_status = {
    "car": "No status received",
    "z2i": "No status received",
    "sprayer": "No status received"
}

recent_status_buffer = ""


def receive_thread():
    global recent_status_buffer

    while True:
        try:
            raw = sock.recv(2048).decode("utf-8")
            if not raw:
                continue

            msgs = raw.split("\n")
            for m in msgs:
                if not m.strip():
                    continue

                try:
                    obj = json.loads(m)
                except:
                    gui_log(f"[Webots Raw] {m}")
                    continue

                recent_status_buffer = m

                r = obj.get("robot", "")
                s = obj.get("status", "")

                if r in robot_status:
                    robot_status[r] = s
                    update_status_labels()

                gui_log(f"[Webots] {m}")

        except Exception as e:
            gui_log(f"Receive error: {e}")
            break


window = ttk.Window(
    title="ChatGPT Multi-Robot Masonry Supervisor",
    themename="vapor",
    size=(1000, 1200)
)

log_box = scrolledtext.ScrolledText(window, wrap=tk.WORD, width=95, height=24)
log_box.pack(padx=10, pady=10)


def gui_log(text):
    log_box.insert(tk.END, text + "\n")
    log_box.see(tk.END)


status_frame = tk.Frame(window, bg="#f0f0f0")
status_frame.pack(fill="x", pady=10)

title = tk.Label(
    status_frame,
    text="Robot Status Dashboard",
    font=("Arial", 16, "bold"),
    bg="#f0f0f0"
)
title.pack(pady=5)


def create_status_card(parent, robot_name):
    card = tk.Frame(parent, bd=2, relief="groove", padx=10, pady=10, bg="#000000")
    name_label = tk.Label(card, text=robot_name, font=("Arial", 14, "bold"))
    name_label.pack(anchor="w")

    status_label = tk.Label(card, text="Status: Unknown", font=("Arial", 12))
    status_label.pack(anchor="w")

    time_label = tk.Label(card, text="Last update: --", font=("Arial", 10))
    time_label.pack(anchor="w")

    return card, status_label, time_label


car_card, car_status_label, car_time_label = create_status_card(status_frame, "CAR")
car_card.pack(fill="x", padx=20, pady=5)

z2i_card, z2i_status_label, z2i_time_label = create_status_card(status_frame, "Z2I ARM")
z2i_card.pack(fill="x", padx=20, pady=5)

sprayer_card, sprayer_status_label, sprayer_time_label = create_status_card(status_frame, "SPRAYER")
sprayer_card.pack(fill="x", padx=20, pady=5)


def color_for_status(state: str):
    state = state.lower()
    if state in ["running", "transport_done", "grasp_done", "spray_done"]:
        return "#c8f7c5"  # green
    elif state in ["busy", "processing"]:
        return "#ffe5b4"  # orange
    elif state in ["error", "fail"]:
        return "#ffb3b3"  # red
    else:
        return "#000000"  # default black


def update_status_labels():
    now = time.strftime("%H:%M:%S")

    car_state = robot_status["car"]
    z2i_state = robot_status["z2i"]
    sprayer_state = robot_status["sprayer"]

    # CAR
    car_status_label.config(text=f"Status: {car_state}")
    car_time_label.config(text=f"Last update: {now}")
    car_card.config(bg=color_for_status(car_state))

    # Z2I ARM
    z2i_status_label.config(text=f"Status: {z2i_state}")
    z2i_time_label.config(text=f"Last update: {now}")
    z2i_card.config(bg=color_for_status(z2i_state))

    # SPRAYER
    sprayer_status_label.config(text=f"Status: {sprayer_state}")
    sprayer_time_label.config(text=f"Last update: {now}")
    sprayer_card.config(bg=color_for_status(sprayer_state))


entry = tk.Entry(window, width=80)
entry.pack(padx=10, pady=5)


def on_send():
    global recent_status_buffer

    user_text = entry.get()
    if not user_text:
        return

    entry.delete(0, tk.END)
    gui_log(f"[User] {user_text}")

    try:
        json_cmd = ask_chatgpt(user_text, recent_status_buffer)
        gui_log(f"[ChatGPT] {json_cmd}")
        send_to_webots(json_cmd)

    except Exception as e:
        gui_log(f"ChatGPT ERROR: {e}")


def send_reset():
    cmd = {"robot": "all", "action": "reset"}
    gui_log("[User] RESET system")
    send_to_webots(json.dumps(cmd))


send_btn = tk.Button(window, text="Send Command", command=on_send, width=20)
send_btn.pack(pady=5)

reset_btn = tk.Button(window, text="Reset System", command=send_reset, width=20)
reset_btn.pack(pady=5)

threading.Thread(target=receive_thread, daemon=True).start()
window.mainloop()



