from controller import Robot
import json

robot = Robot()
timestep = int(robot.getBasicTimeStep())

joint_names = [
    "shoulder_pan_joint",
    "shoulder_lift_joint",
    "elbow_joint",
    "wrist_1_joint",
    "wrist_2_joint",
    "wrist_3_joint"
]

joints = [robot.getDevice(j) for j in joint_names]
for j in joints:
    j.setVelocity(1.2)     



def move_arm(q):
    for i in range(6):
        joints[i].setPosition(q[i])
    for _ in range(120):
        robot.step(timestep)



# Each layer's path points 

layer_points = [
    [  
        [-1.59, -2.34, -1.30, -1.06, 1.48,  3.0],
        [-1.59, -1.89, -2.12, -0.73, 1.48,  3.0],
        [-1.59, -1.16, -2.90, -0.63, 1.48,  3.0]
    ],
    [  
        [-1.59, -2.34, -1.30, -1.06, 1.48,  3.0],
        [-1.59, -1.89, -2.12, -0.73, 1.48,  3.0],
        [-1.59, -1.16, -2.90, -0.63, 1.48,  3.0]
    ],
    [  
        [-1.59, -2.30, -1.25, -1.14, 1.48, 3.0],
        [-1.59, -1.88, -2.06, -0.79, 1.48, 3.0],
        [-1.59, -1.16, -2.75, -0.79, 1.48, 3.0]
    ],
    [   
        [-1.59, -2.28, -1.20, -1.22, 1.48,  3.0],
        [-1.59, -1.86, -2.00, -0.85, 1.48,  3.0],
        [-1.59, -1.16, -2.70, -0.88, 1.48,  3.0]
    ]
]


super_recv = robot.getDevice("super_receiver_sprayer")
super_recv.enable(10)

super_emit = robot.getDevice("super_emitter_sprayer")


def report(status, detail=""):
    msg = {
        "robot": "sprayer",
        "status": status,
        "detail": detail
    }
    super_emit.send(json.dumps(msg).encode())


def receive_supervisor_cmd():
    if super_recv.getQueueLength() == 0:
        return None

    data = super_recv.getString()
    super_recv.nextPacket()

    try:
        return json.loads(data)
    except:
        print("Invalid sprayer JSON:", data)
        return None

home = [0, -1.57, 1.57, 0, 0, 0]

current_layer = 0

while robot.step(timestep) != -1:

    cmd = receive_supervisor_cmd()

    if cmd is None:
        continue

    action = cmd["action"]

    if action == "spray_layer":

        if current_layer >= len(layer_points):
            report("no_more_layers", "All layers completed")
            continue

        print(f"[Sprayer] Now spraying layer {current_layer + 1}")
        for p in layer_points[current_layer]:
            move_arm(p)
        move_arm(home)
        report("spray_done", f"layer {current_layer + 1}")
        current_layer += 1

    elif action == "reset":
        current_layer = 0
        move_arm(home)
        report("reset_done")


    elif action == "pause":
        report("paused")
