from controller import Supervisor
import math
import random
import json

robot = Supervisor()
timestep = int(robot.getBasicTimeStep())


class Car:

    def __init__(self):

        self.motor = []
        self.sensor = []
        self.goods = []
        self.lay_point = [2.8, -1.6]
        self.camera_location = [1.0, -1.0]
        self.times = 0
        self.super_recv = robot.getDevice("super_receiver_car")
        self.super_recv.enable(10)
        self.super_emit = robot.getDevice("super_emitter_car")

    def report(self, status, detail=""):
        msg = {
            "robot": "car",
            "status": status,
            "detail": detail
        }
        self.super_emit.send(json.dumps(msg).encode())

    def receive_supervisor_cmd(self):
        if self.super_recv.getQueueLength() == 0:
            return None

        data = self.super_recv.getString()
        self.super_recv.nextPacket()

        try:
            return json.loads(data)
        except:
            print("Car got INVALID JSON:", data)
            return None

    def enable(self):

        motorname = ['m1', 'm2', 'm3', 'm4']
        for n in motorname:
            m = robot.getDevice(n)
            m.setPosition(float("inf"))
            m.setVelocity(0)
            self.motor.append(m)

        self.sensor.append(robot.getDevice('rotational motor'))  # 0
        self.sensor.append(robot.getDevice('red1'))   # 1
        self.sensor[1].enable(timestep)
        self.sensor.append(robot.getDevice('red2'))   # 2
        self.sensor[2].enable(timestep)
        self.sensor.append(robot.getDevice('gps'))    # 3
        self.sensor[3].enable(timestep)
        self.sensor.append(robot.getDevice('red_back1'))  # 4
        self.sensor[4].enable(timestep)
        self.sensor.append(robot.getDevice('red_back2'))  # 5
        self.sensor[5].enable(timestep)

    def count_distance(self, p1, p2):
        return ((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2) ** 0.5

    def move(self, vl, vr):

        vl = -vl
        vr = -vr

        self.motor[0].setVelocity(vr)
        self.motor[1].setVelocity(vr)
        self.motor[2].setVelocity(vl)
        self.motor[3].setVelocity(vl)

    def follow(self):

        origin = self.sensor[3].getValues()[0:2]
        going_back = False

        while robot.step(timestep) != -1:

            front_left = self.sensor[1].getValue()
            front_right = self.sensor[2].getValue()

            back_left = self.sensor[4].getValue()
            back_right = self.sensor[5].getValue()

            front_left = 1 if front_left > 900 else 0
            front_right = 1 if front_right > 900 else 0
            back_left = 1 if back_left > 900 else 0
            back_right = 1 if back_right > 900 else 0

            gps_value = self.sensor[3].getValues()[0:2]

            if not going_back:

                if front_left and not front_right:
                    self.move(30, -30)
                elif not front_left and front_right:
                    self.move(-30, 30)
                else:
                    self.move(1.0, 1.0)

                distance = self.count_distance(self.lay_point, gps_value)
                if distance < 3.29:

                    self.move(0, 0)

                    # display merchandise
                    if self.times % 2 == 0:
                        self.lay_aside_next(0)
                    else:
                        self.lay_aside_next(1)

                    # Report to the Supervisor
                    self.report("arrived", f"round {self.times}")

                    going_back = True
                    continue

            else:
                if back_left and not back_right:
                    self.move(-30, 30)
                elif not back_left and back_right:
                    self.move(30, -30)
                else:
                    self.move(-1.0, -1.0)

                if self.count_distance(origin, gps_value) < 0.2:
                    self.move(0, 0)
                    break


    def lay_aside_next(self, more):

        generated_points = []

        first_point = [self.camera_location[0], self.camera_location[1]]
        generated_points.append(first_point)

        leave = 3 if more == 0 else 4

        for order in range(leave):

            while True:
                is_good = True
                another = [
                    self.camera_location[0] + random.random() - 0.5,
                    self.camera_location[1] + random.random() - 0.5
                ]

                for gp in generated_points:
                    if self.count_distance(gp, another) < 0.24:
                        is_good = False

                if is_good:
                    generated_points.append(another)
                    break

        print("[Car] Generated positions:", generated_points)

        for i in range(4):
            self.goods[i + self.times * 4].getField("translation").setSFVec3f(
                [generated_points[i][0], generated_points[i][1], 0.04]
            )

        if more:
            idx = 20 if self.times < 2 else 21
            self.goods[idx].getField("translation").setSFVec3f(
                [generated_points[4][0], generated_points[4][1], 0.04]
            )




c = Car()
c.enable()


for i in range(20):
    c.goods.append(robot.getFromDef("b" + str(i + 1)))
c.goods.append(robot.getFromDef("b21"))
c.goods.append(robot.getFromDef("b22"))

print("Car READY")

while robot.step(timestep) != -1:

    cmd = c.receive_supervisor_cmd()
    if cmd is None:
        continue

    action = cmd["action"]

    if action == "start_transport":

        c.report("transport_started")

        c.follow()

        c.times += 1

        c.report("transport_done", f"round {c.times}")

    elif action == "status_query":
        c.report("status_ok", f"round={c.times}")

    elif action == "reset":
        # stop motors and reset internal counters
        c.move(0, 0)
        c.times = 0
        c.report("reset_done", "car reset")
