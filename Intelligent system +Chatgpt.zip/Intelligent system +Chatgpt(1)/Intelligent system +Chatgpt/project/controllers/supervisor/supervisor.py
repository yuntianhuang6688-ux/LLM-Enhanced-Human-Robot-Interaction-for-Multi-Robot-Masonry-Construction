from controller import Supervisor 
import socket
import json
import threading
import os

exec_start_time = 0.0
exec_end_time = 0.0
exp_log_file = "exp_results.csv"
exp_run_id = 0

robot = Supervisor()
timestep = int(robot.getBasicTimeStep())

HOST = "127.0.0.1"
PORT = 8765

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen(1)

print("Supervisor TCP server waiting for GUI...")
client, addr = server.accept()
print("Connected to GUI:", addr)

emit_z2i = robot.getDevice("super_emitter_z2i")
recv_z2i = robot.getDevice("super_receiver_z2i")
if recv_z2i:
    recv_z2i.enable(10)

emit_car = robot.getDevice("super_emitter_car")
recv_car = robot.getDevice("super_receiver_car")
if recv_car:
    recv_car.enable(10)

emit_sprayer = robot.getDevice("super_emitter_sprayer")
recv_sprayer = robot.getDevice("super_receiver_sprayer")
if recv_sprayer:
    recv_sprayer.enable(10)


def safe_json_stream_parser(raw: str):
    buffer = ""
    results = []
    depth = 0

    for ch in raw:
        if ch == "{":
            if depth == 0:
                buffer = ""
            depth += 1
            buffer += ch
        elif ch == "}":
            buffer += ch
            depth -= 1
            if depth == 0:
                try:
                    obj = json.loads(buffer)
                    results.append(obj)
                except:
                    pass
        else:
            if depth > 0:
                buffer += ch
    return results


def send_supervisor_status(status, detail=""):
    msg = {"robot": "supervisor", "status": status, "detail": detail}
    try:
        client.send((json.dumps(msg) + "\n").encode())
    except:
        pass


def dispatch(cmd: dict):
    target = cmd.get("robot", "").lower()
    msg = json.dumps(cmd).encode()

    if target == "z2i" and emit_z2i:
        emit_z2i.send(msg)
    elif target == "car" and emit_car:
        emit_car.send(msg)
    elif target == "sprayer" and emit_sprayer:
        emit_sprayer.send(msg)
    elif target == "all":
        if emit_z2i: emit_z2i.send(msg)
        if emit_car: emit_car.send(msg)
        if emit_sprayer: emit_sprayer.send(msg)

build_active = False
build_target_layers = 0
build_current_layer = 0
build_phase = "idle"


def start_build(layers: int):


    dispatch({"robot": "sprayer", "action": "reset"})

    global build_active, build_target_layers, build_current_layer, build_phase
    build_active = True
    build_target_layers = max(1, layers)

    build_current_layer = 0

    build_phase = "car"

    send_supervisor_status("build_started", f"layers={build_target_layers}")

    dispatch({
        "robot": "car",
        "action": "start_transport",
        "data": {"layer": 1}
    })


def advance_state_with_status(msg_obj: dict):
    global build_active, build_target_layers, build_current_layer, build_phase
    global exec_start_time, exec_end_time, exp_run_id

    if not build_active:
        return

    robot_name = msg_obj.get("robot")
    status = msg_obj.get("status")

    if build_phase == "car" and robot_name == "car" and status == "transport_done":
        build_phase = "arm"
        dispatch({"robot": "z2i", "action": "grasp"})
        return

    if build_phase == "arm" and robot_name == "z2i" and status == "grasp_done":
        build_phase = "spray"
        dispatch({"robot": "sprayer", "action": "spray_layer"})
        return

    if build_phase == "spray" and robot_name == "sprayer" and status == "spray_done":

        build_current_layer += 1

        if build_current_layer >= build_target_layers:
            send_supervisor_status("build_complete",
                                   f"total_layers={build_current_layer}")
            build_active = False
            build_phase = "idle"
            return
        
        build_phase = "car"
        dispatch({"robot": "car", "action": "start_transport"})


def reset_all():
    global build_active, build_phase, build_current_layer

    build_active = False
    build_phase = "idle"
    build_current_layer = 0

    # ask each robot to go home / reset its internal state
    dispatch({"robot": "car", "action": "reset"})
    dispatch({"robot": "z2i", "action": "reset"})
    dispatch({"robot": "sprayer", "action": "reset"})

    send_supervisor_status("system_reset", "all robots reset")


def tcp_thread():
    global exec_start_time, exp_run_id

    while True:
        try:
            raw = client.recv(4096).decode()
            if not raw:
                continue

            for obj in safe_json_stream_parser(raw):

                if obj.get("action") == "build_wall":
                    exp_run_id += 1
                    layers = obj.get("layers") or obj.get("data", {}).get("layers")

                    exec_start_time = robot.getTime()

                    start_build(layers)
                    continue

                if obj.get("action") == "reset":
                    reset_all()
                    continue

                dispatch(obj)

        except Exception as e:
            print("TCP error:", e)
            break


threading.Thread(target=tcp_thread, daemon=True).start()


while robot.step(timestep) != -1:

    for recv in [(recv_z2i, "z2i"), (recv_car, "car"), (recv_sprayer, "sprayer")]:
        device, name = recv
        if device and device.getQueueLength() > 0:
            msg = device.getString()
            device.nextPacket()

            try:
                client.send((msg + "\n").encode())
            except:
                pass

            try:
                obj = json.loads(msg)
                advance_state_with_status(obj)
            except:
                pass
