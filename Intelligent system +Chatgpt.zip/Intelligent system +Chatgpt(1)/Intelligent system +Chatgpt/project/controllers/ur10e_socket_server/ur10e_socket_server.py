from controller import Robot
import socket
import json

robot = Robot()
timestep = int(robot.getBasicTimeStep())

# Load motors
motor_names = [
    "shoulder_pan_joint", "shoulder_lift_joint", "elbow_joint",
    "wrist_1_joint", "wrist_2_joint", "wrist_3_joint"
]
motors = []

for name in motor_names:
    m = robot.getDevice(name)
    m.setPosition(float('inf'))
    m.setVelocity(1.5)
    motors.append(m)

print("[INFO] Motors loaded:", motors)

# TCP server
HOST = "127.0.0.1"
PORT = 8765

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen(1)
print(f"[INFO] Waiting for connection on {HOST}:{PORT} ...")
conn, addr = server.accept()
print("[INFO] Connected from", addr)

buffer = ""

while robot.step(timestep) != -1:
    try:
        chunk = conn.recv(4096).decode()

        if not chunk:
            continue

        buffer += chunk

        # Only process complete lines
        while "\n" in buffer:
            line, buffer = buffer.split("\n", 1)
            if line.strip() == "":
                continue

            print("[RECV]", line)
            msg = json.loads(line)

            # Handle joint command
            if "joints" in msg:
                values = msg["joints"]
                for i in range(6):
                    motors[i].setPosition(values[i])
                print("[INFO] Moving arm to:", values)

    except Exception as e:
        print("Error:", e)
        continue

