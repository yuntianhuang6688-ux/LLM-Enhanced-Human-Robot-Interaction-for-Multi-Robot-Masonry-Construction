
pos_and_size = [

[1,2,3],
[3,4,1],
[5,5,2]

]



sorted_2d = sorted(pos_and_size, key=lambda row: row[2])

print(sorted_2d)