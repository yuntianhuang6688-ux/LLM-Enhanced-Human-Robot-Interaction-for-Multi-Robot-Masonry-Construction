from controller import Supervisor
from controller import CameraRecognitionObject
from math import pi, acos, atan, asin
import json
import time

robot = Supervisor()
timestep = int(robot.getBasicTimeStep())


class Arm:

    def __init__(self, l1, l2):

        self.L1 = l1
        self.L2 = l2
        self.motor = []
        self.camera = None
        self.goods = []
        self.pos = None
        self.times = 0
        self.super_recv = robot.getDevice("super_receiver_z2i")
        self.super_recv.enable(10)
        self.super_emit = robot.getDevice("super_emitter_z2i")
        self.connector = robot.getDevice("connector")
        self.connector.enablePresence(timestep)
 
    def report(self, status, detail=""):
        msg = {
            "robot": "z2i",
            "status": status,
            "detail": detail
        }
        self.super_emit.send(json.dumps(msg).encode())

    def receive_supervisor_cmd(self):
        if self.super_recv.getQueueLength() == 0:
            return None

        data = self.super_recv.getString()
        self.super_recv.nextPacket()

        try:
            return json.loads(data)
        except:
            print("[Z2I] Invalid JSON:", data)
            return None

    def init_goods(self):

        for i in range(20):
            self.goods.append(robot.getFromDef('b' + str(i + 1)))

        self.goods.append(robot.getFromDef('b21'))  # index 20
        self.goods.append(robot.getFromDef('b22'))  # index 21

    def enable(self):

        motorname = ["motor 1", "motor 2", "motor 3", "motor 4"]
        for n in motorname:
            m = robot.getDevice(n)
            m.setVelocity(1.5)
            self.motor.append(m)

        self.camera = robot.getDevice("camera")
        self.camera.enable(timestep)
        self.camera.recognitionEnable(timestep)

    def k(self, x, y):

        theta1 = pi - acos(
            (x ** 2 + y ** 2 - self.L1 ** 2 - self.L2 ** 2) /
            (-2 * self.L1 * self.L2)
        )
        fail = acos(
            (self.L1 ** 2 + x ** 2 + y ** 2 - self.L2 ** 2) /
            (2 * self.L1 * (x ** 2 + y ** 2) ** 0.5)
        )

        if x > 0:
            theta2 = abs(atan(y / x)) - fail
        elif x < 0:
            theta2 = pi - abs(atan(y / x)) - fail
        else:
            theta2 = pi / 2 - fail

        return theta1, theta2, theta1 + theta2 - pi / 2

    def delay(self, t):
        for _ in range(t):
            robot.step(timestep)


    def get_position_of_goods(self):

        pos = []
        self.delay(10)

        x_s = 0.25
        y_s = 1.75

        number = self.camera.getRecognitionNumberOfObjects()
        objs = self.camera.getRecognitionObjects()

        for i in range(number):
            if objs[i]:
                x, y = objs[i].getPositionOnImage()
                x = x_s + (1.5 / 256) * x
                y = y_s - (1.5 / 256) * y
                pos.append((x, y))

        self.pos = pos
        return pos

  
    def get_position_of_goods_update(self):

        pos_and_size = []
        pos = []

        self.delay(10)

        x_s = 0.25
        y_s = 1.75

        number = self.camera.getRecognitionNumberOfObjects()
        obj = self.camera.getRecognitionObjects()

        for i in range(number):

            if obj[i]:
                x, y = obj[i].getPositionOnImage()
                size = max(obj[i].getSizeOnImage())
                color = obj[i].getColors()

                x = x_s + (1.5 / 256) * x
                y = y_s - (1.5 / 256) * y

                pos_and_size.append((x, y, size, color[0]))


        sorted_2d = sorted(pos_and_size, key=lambda row: row[2])
        sorted_2d[0:2] = sorted(sorted_2d[:2], key=lambda row: row[3])

        print("[Z2I] Sorted:", sorted_2d)

        pos.append((sorted_2d[0][0], sorted_2d[0][1]))  # half 1
        pos.append((sorted_2d[2][0], sorted_2d[2][1]))
        pos.append((sorted_2d[3][0], sorted_2d[3][1]))
        pos.append((sorted_2d[4][0], sorted_2d[4][1]))
        pos.append((sorted_2d[1][0], sorted_2d[1][1]))  # half 2

        self.pos = pos
        return pos


    def grasp_goods(self):

        pos_of_goods = self.get_position_of_goods()

        self.motor[0].setPosition(0.3)
        self.delay(5)

        b = -0.242
        n = 0

        for (_x, _y) in pos_of_goods:

            b += 0.242

            a2, a1, a3 = self.k(_x, _y)
            self.motor[1].setPosition(a1)
            self.motor[2].setPosition(a2)
            self.motor[3].setPosition(-a3)
            robot.step(3000)

            # go down
            self.motor[0].setPosition(0.1)
            robot.step(3000)

            if self.connector.getPresence():
                self.connector.lock()

            # lift
            self.motor[0].setPosition(0.1 + 0.05 * self.times)
            robot.step(3000)

            # move to wall
            a2, a1, a3 = self.k(-0.7 - b, 1)
            self.motor[1].setPosition(a1)
            self.motor[2].setPosition(a2)
            self.motor[3].setPosition(-a3)
            robot.step(3000)

            self.connector.unlock()

            # index full bricks
            self.goods[n + self.times * 4].resetPhysics()

            self.motor[0].setPosition(0.3 + 0.1 * self.times)
            self.delay(20)

            n += 1

        self.return_home()

  
    def grasp_goods_update(self):

        pos_of_goods = self.get_position_of_goods_update()

        self.motor[0].setPosition(0.3)
        self.delay(5)

        b = -0.242
        n = 0

        for (_x, _y) in pos_of_goods:

            if n == 0:
                b += (0.121 / 2.0) * 3.0
            elif n == 1:
                b += (0.121 / 2.0) * 3.0
            elif 1 < n < 4:
                b += 0.242
            else:
                b += (0.121 / 2.0) * 3.0

            a2, a1, a3 = self.k(_x, _y)
            self.motor[1].setPosition(a1)
            self.motor[2].setPosition(a2)
            self.motor[3].setPosition(-a3)
            robot.step(3000)

            # descend
            self.motor[0].setPosition(0.1)
            robot.step(3000)

            if self.connector.getPresence():
                self.connector.lock()

            # lift
            self.motor[0].setPosition(0.1 + 0.05 * self.times)
            robot.step(3000)

            # move to wall
            a2, a1, a3 = self.k(-0.7 - b, 1)
            self.motor[1].setPosition(a1)
            self.motor[2].setPosition(a2)
            self.motor[3].setPosition(-a3)
            robot.step(3000)
            self.connector.unlock()

            if n == 4:
                self.goods[20].resetPhysics()  # always b21
            else:
                self.goods[n + self.times * 4].resetPhysics()

            self.motor[0].setPosition(0.3 + 0.1 * self.times)
            self.delay(10)

            n += 1

        self.return_home()

    # ------------------------------------------------------
    def return_home(self):

        self.motor[0].setPosition(0.3)
        self.motor[1].setPosition(-1.2)
        self.motor[2].setPosition(1.8)
        self.motor[3].setPosition(-0.5)
        robot.step(3000)



a = Arm(1.0, 1.0)
a.enable()
a.init_goods()

print("[Z2I] Ready.")

while robot.step(timestep) != -1:

    cmd = a.receive_supervisor_cmd()
    if cmd is None:
        continue

    action = cmd["action"]

    if action == "grasp":

        if a.times % 2 == 0:
            a.grasp_goods()
        else:
            a.grasp_goods_update()

        a.times += 1

        a.report("grasp_done", f"layer={a.times}")

    elif action == "reset":

        a.return_home()
        a.report("reset_done")

    elif action == "pause":
        a.report("paused")
