from controller import Robot

robot = Robot()
timestep = int(robot.getBasicTimeStep())

# ---- UR10e Joint List ----
joint_names = [
    "shoulder_pan_joint",
    "shoulder_lift_joint",
    "elbow_joint",
    "wrist_1_joint",
    "wrist_2_joint",
    "wrist_3_joint"
]

joints = [robot.getDevice(j) for j in joint_names]

for j in joints:
    j.setVelocity(1.2)

def move_arm(q):
    for i in range(6):
        joints[i].setPosition(q[i])
    for _ in range(120):
        robot.step(timestep)

# ------------ spray positions ------------
layer_points = [
    [   
        [-1.59, -2.34, -1.30, -1.06, 1.48, 3.0],
        [-1.59, -1.89, -2.12, -0.73, 1.48, 3.0],
        [-1.59, -1.16, -2.90, -0.63, 1.48, 3.0]
    ],
    [   
        [-1.59, -2.34, -1.30, -1.06, 1.48, 3.0],
        [-1.59, -1.89, -2.12, -0.73, 1.48, 3.0],
        [-1.59, -1.16, -2.90, -0.63, 1.48, 3.0]
    ],
    [   
        [-1.59, -2.30, -1.25, -1.14, 1.48, 3.0],
        [-1.59, -1.88, -2.06, -0.79, 1.48, 3.0],
        [-1.59, -1.16, -2.75, -0.79, 1.48, 3.0]
    ],
    [   
        [-1.59, -2.28, -1.20, -1.22, 1.48, 3.0],
        [-1.59, -1.86, -2.00, -0.85, 1.48, 3.0],
        [-1.59, -1.16, -2.70, -0.88, 1.48, 3.0]
    ]
]

# ------------ communication -------------
receiver = robot.getDevice("receiver")
receiver.setChannel(4)
receiver.enable(10)

emitter = robot.getDevice("emitter")
emitter.setChannel(5)

def send(msg):
    emitter.send(msg.encode())

home = [0, -1.57, 1.57, 0, 0, 0]
current_layer = 0

while robot.step(timestep) != -1:

    # listen for build completion
    if receiver.getQueueLength() > 0:
        msg = receiver.getString()
        receiver.nextPacket()

        print("Sprayer received:", msg)

        if msg == "done_build":

            # If four coats have already been applied → No further spraying is required.
            if current_layer >= 4:
                print("All 4 layers completed. Sprayer stopping.")
                break

            print(f"Spraying layer {current_layer+1}")

            for p in layer_points[current_layer]:
                move_arm(p)

            # return home
            move_arm(home)

            # notify small car 
            send("cement_ok")

            current_layer += 1   


