
from controller import Supervisor
import math
import random

robot = Supervisor()

timestep = int(robot.getBasicTimeStep())

class car:

    def __init__(self):

        self.motor = []
        self.sensor = []

        self.goods = []

        self.lay_point = [2.8, -1.6]
        self.camera_location = [1.0, -1.0]

        # Receiver 1: Received y from z2i
        self.receiver_y = robot.getDevice("receiver_y")
        self.receiver_y.setChannel(1)
        self.receiver_y.enable(10)

        # Receiver 2: Received cement_ok from spray UR10e
        self.receiver_cement = robot.getDevice("receiver_cement")
        self.receiver_cement.setChannel(5)
        self.receiver_cement.enable(10)

        # Emitter: Send y1 to z2i
        self.emitter = robot.getDevice("emitter")
        self.emitter.setChannel(2)

        self.times = 0


    def receive_data(self):

        # Receiving y from z2i
        if self.receiver_y.getQueueLength() > 0:
            data = self.receiver_y.getString()
            self.receiver_y.nextPacket()
            print(f"car Received from z2i: {data}")
            return data

        # Receiving cement_ok from the spray arm
        if self.receiver_cement.getQueueLength() > 0:
            data = self.receiver_cement.getString()
            self.receiver_cement.nextPacket()
            print(f"car Received from sprayer: {data}")
            return data

        return None



    def init_goods(self):

        num = 20

        for i in range(num):
            self.goods.append(robot.getFromDef('b'+str(i+1)))
            print('b'+str(num+1))

        self.goods.append(robot.getFromDef('b21'))
        self.goods.append(robot.getFromDef('b22'))


    def enable(self):

        motorname = ['m1','m2','m3','m4']

        for n in motorname:
            self.motor.append(robot.getDevice(n))
            self.motor[-1].setPosition(float("inf"))
            self.motor[-1].setVelocity(0.0)

        self.sensor.append(robot.getDevice('rotational motor') )

        self.sensor.append(robot.getDevice('red1'))
        self.sensor[1].enable(timestep)

        self.sensor.append(robot.getDevice('red2'))
        self.sensor[2].enable(timestep)

        self.sensor.append(robot.getDevice('gps'))
        self.sensor[3].enable(timestep)



        self.sensor.append(robot.getDevice('red_back1'))
        self.sensor[4].enable(timestep)
        
        self.sensor.append(robot.getDevice('red_back2'))
        self.sensor[5].enable(timestep)
        

    def count_distance(self,p1,p2):

        return ((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)**0.5
        

    def move(self,vl,vr):

        vl = -vl
        vr = -vr

        self.motor[0].setVelocity(vr)
        self.motor[1].setVelocity(vr)
        self.motor[2].setVelocity(vl)
        self.motor[3].setVelocity(vl)

   
 
 
    def follow(self):
    
        origin = self.sensor[3].getValues()[0:2]
        going_back = False
    
        while robot.step(timestep) != -1:
    
            # The first two sensors
            front_left  = self.sensor[1].getValue()
            front_right = self.sensor[2].getValue()
    
            # The rear two sensors
            back_left   = self.sensor[4].getValue()
            back_right  = self.sensor[5].getValue()
    
            # Binarisation
            front_left  = 1 if front_left  > 900.0 else 0
            front_right = 1 if front_right > 900.0 else 0
            back_left   = 1 if back_left   > 900.0 else 0
            back_right  = 1 if back_right  > 900.0 else 0
    
            gps_value = self.sensor[3].getValues()[0:2]
    
            if not going_back:
               
                if front_left and not front_right:
                    self.move(30, -30)
                elif not front_left and front_right:
                    self.move(-30, 30)
                else:
                    self.move(1.0, 1.0)
    
               
                    
                distance = self.count_distance(self.lay_point, gps_value)
                if distance < 3.29:
                    # Upon reaching the destination point: first come to a halt, then unload the cargo beneath the camera.
                    self.move(0, 0)
                    if self.times % 2 == 0:
                        self.lay_aside_next(0)
                    else:
                        self.lay_aside_next(1)

                    # The goods have been arranged; notify the robotic arm that it may commence operations.
                    self.emitter.send("y1".encode('utf-8'))

                    # Mark the start of reversing back to the starting point
                    going_back = True
                    continue

    
            else:
               
                if back_left and not back_right:
                    # The line visible on the left side of the rear indicates the rear is skewed to the right; it requires adjustment to the right (but in reverse).
                    self.move(-30, 30)   
                elif not back_left and back_right:
                    self.move(30, -30)
                else:
                    self.move(-1.0, -1.0)
    
                back_distance = self.count_distance(origin, gps_value)
                if back_distance < 0.2:
                    self.move(0, 0)
                    break
    

    def transport(self):

        bias = 0.2


        for i in range(len(self.goods)):
            self.goods[i].getField("translation").setSFVec3f([-3.0, 1.8+bias*i, 0.7])


    def lay_aside_next(self,more):
        
        generated_points = []

        first_point = [self.camera_location[0],self.camera_location[1]]

        generated_points.append(first_point)

        leave = 0
        if more == 0:
            leave = 3
        else:
            leave = 4

        for order in range(leave):

            while True:
                is_good = True
                another_point = [self.camera_location[0] + random.random() - 0.5,self.camera_location[1] + random.random() - 0.5]

                for o in range(len(generated_points)):
                    res = self.count_distance(generated_points[o],another_point)
                    if res < 0.24:
                        is_good = False
                
                if is_good:
                    generated_points.append(another_point)
                    break

        print(generated_points)
        for i in range(4):

            self.goods[i+self.times*4].getField("translation").setSFVec3f([generated_points[i][0],generated_points[i][1], 0.04])

        if more:
            if c.times < 2:
                self.goods[20].getField("translation").setSFVec3f([generated_points[4][0],generated_points[4][1], 0.04])
            else:
                self.goods[21].getField("translation").setSFVec3f([generated_points[4][0],generated_points[4][1], 0.04])

            
            pass

    def lay_aside(self):
        



        goods_locations = []

        for i in range(4):
            goods_location = [self.camera_location[0] + random.random() - 0.5,self.camera_location[1] + random.random() - 0.5]
            goods_locations.append(goods_location)
            self.goods[i].getField("translation").setSFVec3f([goods_location[0],goods_location[1], 0.1])

        #for loc in goods_locations:

        

        pass

    def clear_receiver_buffer(self):

        while self.receiver.getQueueLength() > 0:
            self.receiver.nextPacket() 

       

c = car()
c.enable()
c.init_goods()

level = 5                 
current_round = 0         # Current round

while robot.step(timestep) != -1:

    # If the total number of cycles is exceeded, it will cease to function.
    if current_round >= level:
        continue

    # Read message (from z2i or UR10e spray)
    msg = c.receive_data()

    # ---------------------------
    # ① Upon receiving z2i's y → the trolley commences transport
    # ---------------------------
    if msg == "y":
        print("Car: start transport cycle")
        c.follow()
        c.times += 1
        current_round += 1

    # ---------------------------
    # ② Received cement_ok from spray arm → Trolley preparing for next cycle
    # ---------------------------
    if msg == "cement_ok":
        print("Car: cement spraying finished → ready for next cycle")
        # If you wish to proceed to the next round automatically, you may write:
        # c.follow()
        pass
    

