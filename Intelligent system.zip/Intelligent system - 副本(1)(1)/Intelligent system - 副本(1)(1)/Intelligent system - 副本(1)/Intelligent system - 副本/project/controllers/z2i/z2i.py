
from controller import Supervisor
from controller import CameraRecognitionObject
from math import pi,acos,atan,asin

robot = Supervisor()

timestep = int(robot.getBasicTimeStep())

import time


class arm:

    def __init__(self,l1,l2):
        
        self.L1 = l1
        self.L2 = l2
        self.motor = []
        self.sensor = []
        self.camera = None
        self.pos = None
        self.goods = []
        self.emitter = None    
        self.receiver = robot.getDevice("receiver")
        self.receiver.setChannel(2)     
        self.receiver.enable(10) 
        self.times = 0

    def receive_data(self):
        if self.receiver.getQueueLength() > 0:
            data = self.receiver.getString()
            self.receiver.nextPacket() 
            print(f"z2i Received: {data}")
            return data

    def send_to_car(self, s):
        self.emitter.setChannel(1)   # ← car receiver_y
        self.emitter.send(s.encode('utf-8'))

    # Spray nozzle UR10e
    def send_to_sprayer(self, s):
        self.emitter.setChannel(4)   # ← Sprayer receiver
        self.emitter.send(s.encode('utf-8'))

    def init_goods(self):

        num = 20

        for i in range(num):
            self.goods.append(robot.getFromDef('b'+str(i+1)))
            print('b'+str(num+1))

        self.goods.append(robot.getFromDef('b21'))
        self.goods.append(robot.getFromDef('b22'))

    def enable(self):

        motorname = ['motor 1','motor 2','motor 3','motor 4']

        for n in motorname:
            self.motor.append(robot.getDevice(n))
            self.motor[-1].setVelocity(1.5)
            
        self.camera = robot.getDevice('camera')
        self.camera.enable(timestep)
        self.camera.recognitionEnable(timestep)

        self.emitter = robot.getDevice("emitter")  
        self.emitter.setChannel(4)    

        
    def k(self,x,y):

        theta1 = pi - acos((x**2 + y**2 - self.L1**2 -self.L2**2)/(-2*self.L1*self.L2))
        fail = acos((self.L1**2 +x**2 +y**2-self.L2**2)/(2*self.L1*(x**2+y**2)**0.5))
        
        if x > 0:
            theta2 = abs(atan(y/x)) - fail
        elif x <0:
            theta2 = pi-abs(atan(y/x))-fail
        else:
            theta2 = pi/2 - fail
            
        return theta1,theta2,theta1+theta2-pi/2
    
    def getpos(self):    
    
        numberOfObjects = self.camera.getRecognitionNumberOfObjects()
        my_object = self.camera.getRecognitionObjects()

        for i in range(numberOfObjects):
            x,y = my_object[i].getPositionOnImage()
            
            x = -(64 - x)*(0.5/64) 
            y = (64 - y)*(0.5/64) + 0.1
            
            return x,y

    def delay(self,t):
    
        for i in range(t):
            robot.step(timestep)

    def get_position_of_goods_update(self):
    
        pos = []
        pos_and_size = []

        self.delay(10)

        x_s = 0.25
        y_s = 1.75

        number = self.camera.getRecognitionNumberOfObjects()
        object = self.camera.getRecognitionObjects()

        for i in range(number):
            
            if object[i]:
                x,y = object[i].getPositionOnImage()
                size = max(object[i].getSizeOnImage())
                color = object[i].getColors()

                
                x = x_s + (1.5/256)*x
                y = y_s - (1.5/256)*y

                pos_and_size.append((x,y,size,color[0]))

        sorted_2d = sorted(pos_and_size, key=lambda row: row[2])
        sorted_2d[0:2] = sorted(sorted_2d[0:2], key=lambda row: row[3])
        print("p a s")
        print(sorted_2d)

        pos.append((sorted_2d[0][0],sorted_2d[0][1]))
        pos.append((sorted_2d[2][0],sorted_2d[2][1]))
        pos.append((sorted_2d[3][0],sorted_2d[3][1]))
        pos.append((sorted_2d[4][0],sorted_2d[4][1]))
        pos.append((sorted_2d[1][0],sorted_2d[1][1]))


        self.pos = pos

        return pos
            
    def get_position_of_goods(self):
    
        pos = []

        self.delay(10)

        x_s = 0.25
        y_s = 1.75

        number = self.camera.getRecognitionNumberOfObjects()
        object = self.camera.getRecognitionObjects()

        for i in range(number):
            
            if object[i]:
                x,y = object[i].getPositionOnImage()
                size = object[i].getSize()
                print("size: ",max(size))

                x = x_s + (1.5/256)*x
                y = y_s - (1.5/256)*y

                pos.append((x,y))

        self.pos = pos

        return pos
     
   
        
    def grasp_goods_update(self):

        pos_of_goods = self.get_position_of_goods_update()

        self.motor[0].setPosition(0.3)
        self.delay(5)
        b = -0.242
        n = 0
        for (_x,_y) in pos_of_goods:
            if n == 0:
                b += (0.121/2.0)*3.0 #+0.01
            elif n == 1:
                b += (0.121/2.0)*3.0
            elif n > 1 and n < 4:
                b += 0.242
            else:
                b += (0.121/2.0)*3.0

            a2,a1,a3 = a.k(_x,_y)
          
            a.motor[1].setPosition(a1)
            a.motor[2].setPosition(a2)
            a.motor[3].setPosition(-a3)
            robot.step(3000)

            self.motor[0].setPosition(0.1)
            robot.step(3000)


            if connector.getPresence():  
                connector.lock()  
                print("Connected!")

            self.motor[0].setPosition(0.1+0.05*self.times) 
            robot.step(3000)
            
            a2,a1,a3 = a.k(-0.7-b,1)
          
            a.motor[1].setPosition(a1)
            a.motor[2].setPosition(a2)
            a.motor[3].setPosition(-a3)
            robot.step(3000)

            connector.unlock()

            if n == 4:
                self.goods[20].resetPhysics()
            else:
                self.goods[n+self.times*4].resetPhysics()
            

            self.motor[0].setPosition(0.3+0.1*self.times)
            self.delay(10)
            n+=1
         # --- Upon completion of the first-level retrieval, automatically return to the safety position. ---
        self.return_home()

        # --- Notification to Spray Using Robotic Arm ---
        self.send_to_sprayer("done_build")

        pass

    def return_home(self):
        # Grab onto the secure position above
        safe_q1 = 0.3      
        safe_arm = [-1.2, 1.8, -0.5]   # motor 1,2,3

        self.motor[0].setPosition(safe_q1)
        self.motor[1].setPosition(safe_arm[0])
        self.motor[2].setPosition(safe_arm[1])
        self.motor[3].setPosition(safe_arm[2])

        # Wait until the robot has finished walking
        robot.step(3000)
        
    def grasp_goods(self):

        pos_of_goods = self.get_position_of_goods()

        self.motor[0].setPosition(0.3)
        self.delay(5)
        b = -0.242
        n = 0
        for (_x,_y) in pos_of_goods:
            b += 0.242
            #move to the pos
            a2,a1,a3 = a.k(_x,_y)
            print(a1,a2,a3)
            a.motor[1].setPosition(a1)
            a.motor[2].setPosition(a2)
            a.motor[3].setPosition(-a3)
            robot.step(3000)

            self.motor[0].setPosition(0.1)
            robot.step(3000)


            if connector.getPresence():  
                connector.lock()  
                print("Connected!")

            self.motor[0].setPosition(0.1+0.05*self.times)
            robot.step(3000)
            
            a2,a1,a3 = a.k(-0.7-b,1)
            print(a1,a2,a3)
            a.motor[1].setPosition(a1)
            a.motor[2].setPosition(a2)
            a.motor[3].setPosition(-a3)
            robot.step(3000)

            connector.unlock()
            self.goods[n+self.times*4].resetPhysics()
            self.motor[0].setPosition(0.3+0.1*self.times)
            self.delay(20)
            n+=1
 
         # --- Upon completion of the first layer of retrieval, automatically return to the safety position. ---
        self.return_home()

        # --- Notification: The spraying robotic arm is capable of spraying. ---
        self.send_to_sprayer("done_build")

connector = robot.getDevice("connector")
connector.enablePresence(timestep) 



a = arm(1.0, 1.0)
a.enable()
a.init_goods()

level = 5                 # How many rounds of “stocking and picking” are required in total
current_round = 0         # Which round is this (counting from 0)
waiting_ack = False       # Has y been issued in the current round? Awaiting y1.

while robot.step(timestep) != -1:

    # 1. Upon completion of the cycle, operation ceases.
    if current_round >= level:
        continue

    # 2. If y has not been sent in this round, send y to the vehicle.
    if not waiting_ack:
        a.send_to_car('y')        
        waiting_ack = True

    # 3. Monitor messages
    msg = a.receive_data()
    if msg == 'y1':
        # Trolley confirms bricks are in place → Commencing retrieval
        if a.times % 2 == 0:
            a.grasp_goods()
        else:
            a.grasp_goods_update()

        # Having completed this round of bricks, proceed to the next round.
        a.times += 1
        current_round += 1
        waiting_ack = False





